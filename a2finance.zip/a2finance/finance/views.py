from django.shortcuts import render
from . models import services

# Create your views here.
  
def home_page(request):
    
    
    serv1 = services()
    serv1.name = "Python Web development "
    serv1.desc = "Learn to build websites with HTML , CSS , Bootstrap , Javascript , jQuery , Python 3 , and Django!"
    serv1.img = 'static/images/service_1.jpg'
    serv1.price = "$255"

    serv2= services()
    serv2.name = "Network Infrastructure Essential"
    serv2.desc = "designed to build an understanding of various network infrastructure components"
    serv2.img = 'static/images/service_2.jpg'
    serv2.price = '$300'

    serv3 = services()
    serv3.name = "Mobile Programming"
    serv3.desc = "To impart the fundamentals concepts of mobile technologies, discuss the current trends in mobile technologies"
    serv3.img = "static/images/service_3.jpg"
    serv3.price = '$350'

    serv4 = services()
    serv4.name = "Real Time Operating System"
    serv4.desc = "This course will help students to understand basic concepts, building blocks for embedded systems."
    serv4.img = "static/images/service_04.jpg"
    serv4.price = '$450'

    serv5 = services()
    serv5.name = "Introduction to Cloud Computing"
    serv5.desc = " Cloud computing solutions are currently used in settings where they have been developed without addressing a common programming model"
    serv5.img = "static/images/service_05.png"
    serv5.price = '$345'

    serv6 = services()
    serv6.name = "Advance Web Scripting"
    serv6.desc = "Create the dynamic Web pages using jQuery Understand MVC architecture of Angular js"
    serv6.img = "static/images/service_06.jpg"
    serv6.price = "#453"

   
    allservices = [serv1, serv2, serv3, serv4, serv5, serv6]

    return render(request,"one-page.html", {"allservices" : allservices} )




    
    
   
    
    
    
    
    
    
    
from django.db import models

# Create your models here.

class services:
    name: str
    desc: str
    img : str
    price : int
    
    

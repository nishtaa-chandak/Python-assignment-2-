from django.shortcuts import render 
from django.http import  request

from resume.models import skills

# Create your views here.
def home_page(request):

    skills1 = skills()
    skills1.name = "Bug hunting"
    skills1.desc = "A bug bounty is a program offered to individuals who identify and report bugs back to companies, websites or developers. These programs reward individuals for finding vulnerabilities before they become security issues"


    skills2 = skills()
    skills2.name = "web development"
    skills2.desc = "Web development is the building and maintenance of websites; it's the work that happens behind the scenes to make a website look great"

    skills3  = skills()
    skills3.name = "Video editing "
    skills3.desc = "Used to edit create videos. Fluent with wondershare filmora, Adobe procreate, Veed"

    skills4 = skills()
    skills4.name = "Social media marketing "
    skills4.desc = "Social media marketing is the use of social media platforms to connect with your audience to build your brand, increase sales, and drive website traffic. ... The major social media platforms (at the moment) are Facebook, Instagram, Twitter, LinkedIn, Pinterest, YouTube, and Snapchat"

    skills5 = skills()
    skills5.name = "Ethical hacking"
    skills5.desc = "The Certified Ethical Hacker (C|EH) credentialing and provided by EC-Council is a respected and trusted ethical hacking program in the industry. "

    skills6 = skills()
    skills6.name = "Full stack engineer"
    skills6.desc = "A full-stack engineer is a software developer that's writing code not only for the user's front-end web applications or mobile applications, but they're also writing API code that sits in the middle, they're writing server code that sits in the back, and they're also connecting and communicating with databases"
    

    port1 = skills()
    port1.name = "SICSR"
    port1.img = "static/img/work-1.jpg"

    port2 = skills()
    port2.name = "VERGE "
    port2.img = "static/img/work-2.jpg"

    port3 = skills()
    port3.name = "GG"
    port3.img = "static/img/work-3.jpg"

    port4 = skills()
    port4.name = "NETFILX"
    port4.img = "static/img/work-4.jpg"

    port5 = skills()
    port5 .name = "INSTAGRAM "
    port5.img  = "static/img/work-5.jpg"

    port6 = skills()
    port6.name = "ONE+"
    port6.img = "static/img/work-6.jpg"

    allports = [port1, port2, port3, port4, port5, port6]
   
    allskills = [skills6, skills4, skills1, skills5, skills2, skills3]
    return render(request,'index.html', {"allskills" : allskills, "allports" : allports})
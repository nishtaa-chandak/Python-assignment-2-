from django.db import models

# Create your models here.
class skills:
    name : str
    desc : str
    img  : str 